for i in range(11):
	print("acc = ", 4.9)
	for j in range(5):
		print("velocity at time ", i+(0.1*j)," is ", (i+(j*0.1))*4.9)
